(function() {
    var promiseObj = WebSquare.startApplication();
    promiseObj.then(function(resolve, reject) {
        // to do
    });
})();
window.externalValue = {
    hybridApp: true
}
window.WebSquareExternal = {
    baseURI: location.origin + "/websquare/"
}